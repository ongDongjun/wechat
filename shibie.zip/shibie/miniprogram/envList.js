const envList = [{"envId":"forest-annimal-1g6i3v9j79b369f9","alias":"forest-annimal"}]
const isMac = false
module.exports = {
    envList,
    isMac
}