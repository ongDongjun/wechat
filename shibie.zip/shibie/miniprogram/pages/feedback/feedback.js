// pages/page2/page2.js

let name="";
Page({
  data: {
    src:[60],

    feedbackText: '', // 存储用户输入的反馈文字

  },
  
upimage(){
  // 上传图片
  let that = this;
  wx.chooseImage({
    count:1,
    sizeType: ['original','compressed'],
    sourceType:['album','camera'],
    success(res){
      //将图片渲染
        console.log(res.tempFilePaths)
        //拿到的图片地址链接
        that.setData({
          src: res.tempFilePaths
        }  )

      }
  })
},
viewimager(){
  let that = this
   wx.previewImage({
     current:'',
     urls:that.data.src
   })
},
upimagecolod(){
  let that = this;
  wx.showLoading({
    title:'上传中'
  })
  let time = Date.parse(new Date())/1000
  console.log(that.data.src.lastIndexOf)
  for(let i=0;i<that.data.src.length;i++){
    wx.cloud.uploadFile({
      cloudPath:'2023-8-17/'+time+i,
      filePath: that.data.src[i],
    }).then(res =>{
       wx.hideLoading()
         wx.showToast({
           title:'上传成功',
         })
         console.log(res);
      }).catch(_eooro =>{
   })
  }
},

//-------意见反馈部分

inputText(event) {
  this.setData({
    feedbackText: event.detail.value,
  });
},
submitFeedback() {
  // 上传数据至微信云服务端
  const imageSrc = this.data.imageSrc;
  const feedbackText = this.data.feedbackText;

    if ( !feedbackText) {
    wx.showToast({
      title: '请填写文字',
      icon: 'none',
    });
    return;
  }

      wx.cloud.callFunction({
        name: 'saveFeedback',
        data: {
         // imageUrl: imageUrl,
          feedbackText: feedbackText,
        },
        success: (res) => {
          wx.showToast({
            title: '反馈已提交',
            icon: 'success',
          });
        },
        fail: (err) => {
          wx.showToast({
            title: '提交失败，请稍后重试',
            icon: 'none',
          });
        },
      });
    },
  
    onLoad: function () {
      // 初始化云开发
      wx.cloud.init({
        env: 'forest-annimal-1g6i3v9j79b369f9', // 替换成你的环境 ID
      });
    },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad() {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */

  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }


})