// pages/collect/collect.js
let name="";
Page({
  data: {
    src:[],
  },

  // 上传图片
  upimage(){
   let that = this;
  wx.chooseImage({
    count:1,//选择图片的个数
    sizeType: ['original','compressed'],
    sourceType:['album','camera'],
    success(res){
      //将图片渲染
        console.log(res.tempFilePaths)
        //拿到的图片地址链接
        that.setData({
          src: res.tempFilePaths
        }  )
      }
  })
},
viewimager(){
  let that = this
   wx.previewImage({
     current:'',
     urls:that.data.src
   })
},
upimagecolod(){
  let that = this;
  wx.showLoading({
    title:'添加中...',// title:'上传中'
  })
  let time = Date.parse(new Date())/1000
  console.log(that.data.src.lastIndexOf)
  for(let i=0;i<that.data.src.length;i++){
    wx.cloud.uploadFile({
      cloudPath:'2023-8-17/'+time+i,
      filePath: that.data.src[i],
    }).then(res =>{
       wx.hideLoading()
         wx.showToast({
          title:'已添加到收藏列表',// title:'上传成功',
         })
         console.log(res);
      }).catch(_eooro =>{
   })
  }
},

})