const grant_type = 'client_credentials'
const client_id = 'H2DsK6EXTe67teXts2MpuY12'
const client_secret = 'aEbalt5W9aRIs9uaKZXww1c2voARNg2S'
var token = null
var base64 = null
var apiUrl = null

//初始化界面
Page({
//分享聊天和分享朋友圈功能
  onShareAppMessage: function () {
        return { 
        title: '森林动物识别',
        desc: '一个能识别动物的小程序',
        path: '/page/index/index'
        }
        },
        onLoad: function () {
          wx.showShareMenu({
            withShareTicket:true,
            menus:['shareAppMessage','shareTimeline']  
            })
        },
  data: {
    imageUrl: "/images/test_animal.jpg",
    message: 'Welcome to ImageMaster !\n Author : ZhangH.J.',
    load_logo: 'waiting',
    load_title: "等待上传图片",
    load_message: " 请上传图片",
    btn_enable:true
  },  
  //  跳转部分
  response: function(){
    wx.navigateTo({
      url: '../feedback/feedback',
    })
  },
  collect: function(){
    wx.navigateTo({
      url: '../collect/collect',
    })
  },
  
  goto_collect: function(){
    wx.navigateTo({
     // url: 'pages/page2/page2',
     url: '/miniprogram/pages/page2/page2',
    })
  },

//识别网络请求部分
  onReady: function(res) {
    // get access_token from BaiDu API
    wx.request({
      url: 'https://aip.baidubce.com/oauth/2.0/token?grant_type=' + grant_type + '&client_id=' + client_id + '&client_secret=' + client_secret,
      method: 'POST',
      success: function (res) {
        console.log('Request successful !')
        // console.log(res.data)
        token = res.data.access_token;
        console.log('My token is : ' + token);
      },
      fail: function (res) {
        console.log('Fail to request !')
        console.log(res)
      }
    })
  },


   /** 上传按钮点击监听 -----------从聊天记录中上传*/
   async uploadFileTap(res) {
    try {
            const res = await wx.chooseMessageFile({
              count: 1,
              type: 'image',
            });
        
            const filePath = res.tempFiles[0].path;
        
            this.setData({
              load_title: "正在上传",
              load_message: "正在上传图片，请稍后"
            });
        
            // Set image URL and display success message
            this.setData({
              imageUrl: filePath,
              load_logo: "success",
              load_message: "等待识别图片，请点击识别按钮以识别图片",
              load_title: "上传图片成功",
              btn_enable: false
            });
        
            console.log('Image Path is : ' + filePath);
        
            // Read file as base64
            const base64Data = await new Promise((resolve, reject) => {
              wx.getFileSystemManager().readFile({
                filePath: filePath,
                encoding: 'base64',
                success: res => {
                  resolve(res.data);
                },
                fail: err => {
                  reject(err);
                }
              });
            });
        
            base64 = base64Data;
        
          } catch (error) {
            this.setData({
              load_title: "上传失败",
              load_message: "上传图片失败，请重试"
            });
            console.error("Error while choosing message file:", error);
          }
        }
,


  
//选择图片类型
  chooseMessageFile(count, type) {
     var that = this
        that.setData({
          load_title: "正在上传",
          load_message: "正在上传图片,请稍后"      
        })
      wx.chooseMessageFile({
        count: 1,
        type: 'image',
            success(res) {
              var tempFilePaths = res.tempFilePaths
              apiUrl = 'https://aip.baidubce.com/rest/2.0/image-classify/v1/animal'//https://aip.baidubce.com/rest/2.0/image-classify/v1/animal
              that.setData({
                imageUrl: tempFilePaths,
                load_logo: "success",
                load_message: "等待识别图片,请点击识别按钮以识别图片",
                load_title: "上传图片成功",
                btn_enable: false
              })
              console.log('My API URL is : ' + apiUrl)
              console.log('Image Path is : ' + tempFilePaths)
              // console.log(res)
              wx.getFileSystemManager().readFile ({
                filePath: res.tempFilePaths[0],
                encoding: 'base64',
                // complete: res=> {
                //   console.log('complete')
                //   console.log(res)
                // },
                success: res => {
                  base64 = res.data
                  // console.log('data:image/png;base64,' + base64)
                }
              })
            }
          })
      
  },
/*--------------------------------------------------------从聊天记录中上传*/

  get_Animal_image: function(res) {
    var that = this
    that.setData({
      load_title: "正在上传",
      load_message: "正在上传图片,请稍后"      
    })
    wx.chooseImage({
      count: 1,
      sizeType: ['original', 'compressed'],
      sourceType: ['album', 'camera'],
      success(res) {
        var tempFilePaths = res.tempFilePaths
        apiUrl = 'https://aip.baidubce.com/rest/2.0/image-classify/v1/animal'//https://aip.baidubce.com/rest/2.0/image-classify/v1/animal
        that.setData({
          imageUrl: tempFilePaths,
          load_logo: "success",
          load_message: "等待识别图片,请点击识别按钮以识别图片",
          load_title: "上传图片成功",
          btn_enable: false
        })
        console.log('My API URL is : ' + apiUrl)
        console.log('Image Path is : ' + tempFilePaths)
        // console.log(res)
        wx.getFileSystemManager().readFile ({
          filePath: res.tempFilePaths[0],
          encoding: 'base64',
          // complete: res=> {
          //   console.log('complete')
          //   console.log(res)
          // },
          success: res => {
            base64 = res.data
            // console.log('data:image/png;base64,' + base64)
          }
        })
      }
    })

  },

  

  recognition_image: function(res) {
    var that = this
    that.setData({
      load_title: "正在识别",
      load_message: "正在识别图片,请稍后"
    })
    wx.request({
      url: apiUrl + '?access_token=' + token,
      method: 'POST',
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      data: {
        image: base64
      },
      success: res => {
        var result = null
        var score = 0
        console.log('recognition_image Success')
        if(res.data.result == null) {
          console.log(res.data.error_msg)
          console.log(base64)
          result = res.data.error_msg
        }else {
          console.log(res.data.result)
          result = res.data.result[0].name
          score = res.data.result[0].score
        }
        that.setData({
          load_title: '识别结果 : ' + result,
          load_message: '置信度' + score
        })
      }
    })
  }
})
